"""
Current version (short and full names).
"""

__version_short__ = '1.2'
__version_full__ = '1.2.0'

__version__ = __version_full__